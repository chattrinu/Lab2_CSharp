﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chattrin_Udomsomporn_Ex_03
{
    internal class SortTest
    {
        static void Main(string[] args)
        {
            // call static method 
            SortValues.SortNumbers(329,468, 17, 651, 180, 253);
            
        }
    }
}
