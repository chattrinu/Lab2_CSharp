﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chattrin_Udomsomp_Ex01
{
    internal class QuestionBankTest
    {
        static void Main(string[] args)
        {
            QuestionBank question = new QuestionBank();
            question.InputAnswer();



        }
    }
}
